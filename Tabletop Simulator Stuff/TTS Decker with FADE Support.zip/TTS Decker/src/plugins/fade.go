package plugins

import "fmt"
import "net/http"
import "net/url"
import "errors"
import "os"
import "io"
import "encoding/json"

const Fade = "fade"

type FadeCard struct {
	Images struct{
		
		Large string `json:"large"`
		
	} `json:"image_uris"`
}

func init() {

	var client http.Client

	RegisterHeaders(Fade, []string{"Fighter's Arena, Destructive Encounters", "FADE", "F.A.D.E."})
	
	RegisterBack(Fade, "https://github.com/XKirby/F.A.D.E.-TCG/raw/master/LackeyCCG%20Plugin/fade/sets/setimages/general/cardback.png")
	
	RegisterPlugin(Fade, func(name, info string, detecting bool) string {
		
		if _, err := os.Stat( DeckerCachePath + "/cards/fade/" + name + ".png"); !os.IsNotExist(err) {
			return Fade
		}
		
		response, err := client.Get("https://github.com/XKirby/F.A.D.E.-TCG/raw/master/LackeyCCG%20Plugin/fade/sets/setimages/cards/"+url.QueryEscape(name)+".png")
		Handle(err)
		
		if response.StatusCode != 200 {
			//Not sure what happens here.
			fmt.Println("possible error check card! " + name + ", status " + response.Status)
		}
		
		//Now we should parse the Json data of the card.
		var decoder = json.NewDecoder(response.Body)
		var card FadeCard
		
		err = decoder.Decode(&card)
		Handle(err)
		
		var image = card.Images.Large
		var imagename string

		//Now we can check if we already have the image cached, otherwise download it.
		if _, err := os.Stat(DeckerCachePath  + "/cards/fade/" + name + ".png"); !os.IsNotExist(err) {
			return Fade
		} else {
			if ! detecting {
				fmt.Println("getting", image)
			}
			response, err = client.Get(image)
			Handle(err)
			if response.StatusCode == 404 {
				//Broken link?
				Handle(errors.New("broken link? " + image))
			} else {
				if response.StatusCode != 200 {
					fmt.Println("possible error check file! " + DeckerCachePath + "/cards/fade/" + imagename + ".png, status " + response.Status)
				}
				//Download and Save image.
				var imageOut *os.File
				if info != "" {
					imageOut, err = os.Create(DeckerCachePath + "/cards/fade/" + imagename + ".png")
				} else {
					imageOut, err = os.Create(DeckerCachePath + "/cards/fade/" + name + ".png")
				}
				Handle(err)
				io.Copy(imageOut, response.Body)
				imageOut.Close()
				return Fade
			}
		}
		return None
	})
}